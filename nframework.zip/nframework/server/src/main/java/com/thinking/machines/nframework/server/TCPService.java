package com.thinking.machines.nframework.server;
import java.lang.reflect.*;
public class TCPService
{
public Class c;
public Method method;
public String path;
}