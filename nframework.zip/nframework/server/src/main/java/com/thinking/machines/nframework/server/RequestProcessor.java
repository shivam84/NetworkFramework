package com.thinking.machines.nframework.server;
import com.thinking.machines.nframework.common.*;
import java.io.*;
import java.net.*;
import java.nio.charset.*;
import java.lang.reflect.*;
public class RequestProcessor extends Thread
{
private NFrameworkServer nFrameworkServer;
private Socket socket;
RequestProcessor(NFrameworkServer nFrameworkServer,Socket socket)
{
this.nFrameworkServer=nFrameworkServer;
this.socket=socket;
start();
}
public void run()
{
Response responseObject=null;
try
{
InputStream is=socket.getInputStream();
OutputStream os=socket.getOutputStream();
int bytesToReceive=1024;
byte temp[]=new byte[1024];
byte header[]=new byte[1024];
int k;
int i=0;
int j=0;
int bytesReadCount;
while(j<bytesToReceive)
{
bytesReadCount=is.read(temp);                           //temp=00000......161
if(bytesReadCount==-1) continue;                         //bytes read kare(bytesReadCount)=1024 
for(k=0;k<bytesReadCount;k++)
{
header[i]=temp[k];                          //header[]=000000.........161
i++;
}
j=j+bytesReadCount;
}
int requestLength=0;
i=1;
j=1023;
while(j>=0)
{
requestLength=requestLength+(header[j]*i);         //161
i=i*10;
j--;
}
byte ack[]=new byte[1];
ack[0]=1;
os.write(ack,0,1);
os.flush();
byte request[]=new byte[requestLength];
bytesToReceive=requestLength;
i=0;
j=0;
while(j<bytesToReceive)
{
bytesReadCount=is.read(temp);
if(bytesReadCount==-1) continue;
for(k=0;k<bytesReadCount;k++)
{
request[i]=temp[k];
i++;
}
j=j+bytesReadCount;
}

String requestJsonString=new String(request,StandardCharsets.UTF_8);
Request requestObject=JSONUtil.fromJson(requestJsonString,Request.class);
TCPService tcpService=this.nFrameworkServer.getTCPService(requestObject.getServicePath());
responseObject=new Response();
if(tcpService==null)
{
responseObject.setSuccess(false);
responseObject.setResult(" ");
responseObject.setException(new RuntimeException("Invalid path "+requestObject.getServicePath()));
}
else
{
Class c=tcpService.c;
Method method=tcpService.method;
try
{
Object serviceObject=c.newInstance();
Object result=method.invoke(serviceObject,requestObject.getArguements());
responseObject.setSuccess(true);
responseObject.setResult(result);
responseObject.setException(null);
}catch(IllegalAccessException|InstantiationException e)
{
System.out.println(e);
responseObject.setSuccess(false);
responseObject.setResult(null);
responseObject.setException(new RuntimeException("Unable to create object"));
}
catch(InvocationTargetException ite)
{
Throwable t=ite.getCause();
responseObject.setSuccess(false);
responseObject.setResult(null);
responseObject.setException(t);
System.out.println(t);
}

String responseJsonString=JSONUtil.toJson(responseObject);
byte objectByte[]=responseJsonString.getBytes(StandardCharsets.UTF_8);
int responseLength=objectByte.length;
int x;
i=1023;
x=responseLength;
header=new byte[1024];
while(x>0)
{
header[i]=(byte)(x%10);
x=x/10;
i--;
}
os.write(header,0,1024);
os.flush();								
//System.out.println("Reponse Header Set "+responseLength);     //19
while(true)
{
bytesReadCount=is.read(ack);
if(bytesReadCount==-1) continue;
break;
}
//System.out.println("Ack. Received");
int bytesToSend=responseLength;
int chunkSize=1024;
j=0;
while(j<bytesToSend)
{
if((bytesToSend-j)<chunkSize) chunkSize=bytesToSend-j;
os.write(objectByte,j,chunkSize);
os.flush();
j=j+chunkSize;
}
//System.out.println("Response Sent");
while(true)
{
bytesReadCount=is.read(ack);
if(bytesReadCount==-1) continue;
break;
}
socket.close();
}
}catch(IOException e)
{
System.out.println(e);
}
}

}