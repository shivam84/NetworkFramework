import com.thinking.machines.nframework.client.*;
public class BankUI
{
public static void main(String gg[])
{

NFrameworkClient client=new NFrameworkClient();
try
{
String branchname=(String)client.execeute("/banking/branchName",gg[0]);
System.out.println("BranchName "+branchname);
}catch(Throwable t)
{
System.out.println(t.getMessage());
}
}
}