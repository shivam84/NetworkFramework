import com.thinking.machines.nframework.server.*;
import java.lang.annotation.*;
@Path("/banking")
public class BankServer
{
@Path("/branchName")
public String getBranchName(String city) throws BankingException
{
if(city.equals("UJJAIN"))
{
return "Freeganj";
}
if(city.equals("Mumbai"))
{
return "Colaba";
}
//return "No branch found";
throw new BankingException("No branch found");
}
public static void main(String gg[])
{
NFrameworkServer server=new NFrameworkServer();
server.registerClass(BankServer.class);
server.start();
}
} 