package com.thinking.machines.nframework.common.exceptions;
public class NetworkException extends Exception
{
public NetworkException()
{

}
public NetworkException(String message)
{
super(message);
}

}